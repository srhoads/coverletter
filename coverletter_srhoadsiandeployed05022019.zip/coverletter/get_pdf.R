source('simple_coverletter.R')

simple_coverletter(
  company="SRhoadsianCo",
  position="Cat Whisperer",
  paragraph1="I like to write code sometimes",
  paragraph2="My eyes hurt",
  filename_override=NULL
)



# source('jadrian_coverletter_fxn.R')
# jadrian_coverletter_fxn(company, position, additional_paragraph, filename_override)

